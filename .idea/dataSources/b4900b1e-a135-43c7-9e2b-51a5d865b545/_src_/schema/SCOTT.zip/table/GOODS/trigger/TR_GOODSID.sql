create trigger TR_GOODSID
	before insert
	on GOODS
	for each row
declare
  -- local variables here
begin
  select to_char(sysdate,'yyyymmddhhmm')||LPAD(auto_id.nextval,5,'0') into :new.id from dual;
end tr_GoodsID;
