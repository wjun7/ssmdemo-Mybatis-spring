create trigger TR_CGETID
	before insert
	on CATEGORY
	for each row
declare
  -- local variables here
begin
  select to_char(sysdate,'yyyymmddhhmm')||LPAD(auto_id.nextval,5,'0') into :new.id from dual;
end tr_cgetID;